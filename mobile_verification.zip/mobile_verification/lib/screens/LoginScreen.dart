import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneController = TextEditingController();
  final _codeController = TextEditingController();
  FirebaseAuth _auth = FirebaseAuth.instance;

  bool _codeSent = false;
  String _verificationId = "";

  Future<void> _verifyPhoneNumber(String mobile) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: mobile,
      timeout: Duration(seconds: 60),
      verificationCompleted: (AuthCredential authCredential) async {
        try {
          await _auth.signInWithCredential(authCredential);
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) => HomeScreen(_auth.currentUser!)),
          );
        } catch (e) {
          print(e);
        }
      },
      verificationFailed: (FirebaseAuthException authException) {
        print(authException.message);
      },
      codeSent: (String verificationId, int? forceResendingToken) {
        setState(() {
          _codeSent = true;
        });
      },
      codeAutoRetrievalTimeout: (String verificationId) {
        verificationId = verificationId;
        print(verificationId);
        print("Timeout");
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                "Mobile Verfication using OTP",
                style: TextStyle(
                  color: Colors.blue[300],
                  fontSize: 35,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 32),
              _codeSent
                  ? Column(
                      children: [
                        TextField(
                          decoration: InputDecoration(
                            hintText: "Enter OTP",
                          ),
                          controller: _codeController,
                        ),
                        SizedBox(height: 16),
                        TextButton(
                          onPressed: () async {
                            final smsCode = _codeController.text.trim();

                            AuthCredential _credential =
                                PhoneAuthProvider.credential(
                              verificationId: _verificationId,
                              smsCode: smsCode,
                            );
                            try {
                              await _auth.signInWithCredential(_credential);
                              Navigator.pushReplacement(
                                context,
                                MaterialPageRoute(
                                  builder: (context) =>
                                      HomeScreen(_auth.currentUser!),
                                ),
                              );
                            } catch (e) {
                              print(e);
                            }
                          },
                          child: Text("Verify OTP"),
                        ),
                        SizedBox(height: 16),
                        TextButton(
                          onPressed: () {
                            setState(() {
                              _codeSent = false;
                            });
                          },
                          child: Text("Back"),
                        ),
                        SizedBox(height: 16),
                        TextButton(
                          onPressed: () {
                            final mobile = _phoneController.text.trim();
                            _verifyPhoneNumber(mobile);
                          },
                          child: Text("Resend OTP"),
                        ),
                      ],
                    )
                  : Column(
                      children: [
                        TextFormField(
                          decoration: InputDecoration(
                            hintText: "Enter phone number",
                          ),
                          controller: _phoneController,
                        ),
                        SizedBox(height: 16),
                        ElevatedButton(
                          onPressed: () {
                            final mobile = _phoneController.text.trim();
                            _verifyPhoneNumber(mobile);
                          },
                          child: Text("Next"),
                        ),
                      ],
                    ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final User user;

  HomeScreen(this.user);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('Logged in as:'),
            Text(
              user.phoneNumber ?? '',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}

void main() => runApp(MaterialApp(home: LoginScreen()));
