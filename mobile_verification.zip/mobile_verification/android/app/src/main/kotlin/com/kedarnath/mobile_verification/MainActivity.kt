package com.kedarnath.mobile_verification

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
